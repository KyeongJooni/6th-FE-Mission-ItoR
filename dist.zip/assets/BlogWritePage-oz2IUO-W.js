import{j as t}from"./react-query-DEbDJb5v.js";import{a as r,j as $,e as _,g as H}from"./vendor-CLhophSa.js";import{r as P}from"./editor-MdmiTulm.js";import{e,g as G,h as W,u as q,i as F,a as U,j as E,k as z,I as N,T as C,l as M,S as L,P as Q,m as X}from"./index-BLxAB3Pc.js";import{S as V}from"./add_photo_alternate-DUnvUglh.js";const Y=o=>r.createElement("svg",{width:24,height:24,viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg",...o},r.createElement("g",{clipPath:"url(#clip0_39_20891)"},r.createElement("path",{d:"M20 6H12L10 4H4C2.9 4 2.01 4.9 2.01 6L2 18C2 19.1 2.9 20 4 20H20C21.1 20 22 19.1 22 18V8C22 6.9 21.1 6 20 6ZM20 18H4V8H20V18Z",fill:"currentColor"})),r.createElement("defs",null,r.createElement("clipPath",{id:"clip0_39_20891"},r.createElement("rect",{width:24,height:24,fill:"white"})))),Z=o=>{const[i,d]=r.useState(!1);return r.useEffect(()=>{const m=window.matchMedia(o);d(m.matches);const n=a=>{d(a.matches)};return m.addEventListener("change",n),()=>{m.removeEventListener("change",n)}},[o]),i},K=(o=768)=>Z(`(max-width: ${o-1}px)`),J=()=>`
  /* 마크다운 에디터 */
  .w-md-editor-toolbar {
    height: ${e.EDITOR.TOOLBAR_HEIGHT} !important;
    padding: ${e.SPACING.TOOLBAR_PADDING} !important;
    border-radius: ${e.EDITOR.BORDER_RADIUS} ${e.EDITOR.BORDER_RADIUS} 0 0 !important;
  }

  .w-md-editor-toolbar button {
    width: 16px !important;
    height: 16px !important;
    margin: 0 4px !important;
  }

  .w-md-editor-toolbar .w-md-editor-toolbar-divider {
    margin: 0 12px !important;

  }

  .w-md-container {
    height: ${e.EDITOR.HEIGHT} !important;
    border-radius: ${e.EDITOR.BORDER_RADIUS} !important;
  }

  /* ReactQuill 공통 스타일 */
  .ql-toolbar {
    height: ${e.EDITOR.TOOLBAR_HEIGHT} !important;
    border-radius: ${e.EDITOR.BORDER_RADIUS} ${e.EDITOR.BORDER_RADIUS} 0 0 !important;
  }

  .ql-container {
    height: ${e.EDITOR.HEIGHT} !important;
    border-radius: 0 0 ${e.EDITOR.BORDER_RADIUS} ${e.EDITOR.BORDER_RADIUS} !important;
  }

  .ql-editor {
    height: ${e.EDITOR.EDITOR_HEIGHT} !important;
  }

  .ql-editor img {
    max-width: 100% !important;
    height: auto !important;
    display: block !important;
    margin: ${e.SPACING.IMAGE_MARGIN} !important;
  }

  .ql-editor.ql-blank::before {
    font-style: normal !important;
  }

  /* 모바일용 ReactQuill */
  .mobile-quill {
    width: 357px !important;
    max-width: 357px !important;
  }

  .mobile-quill .ql-toolbar {
    border: 1px solid ${e.COLORS.BORDER} !important;
    border-bottom: none !important;
    border-radius: 4px 4px 0 0 !important;
    background-color: ${e.COLORS.TOOLBAR_BG} !important;
    padding: ${e.SPACING.TOOLBAR_PADDING} !important;
  }

  .mobile-quill .ql-container {
    width: 100% !important;
    height: auto !important;
    min-height: ${e.MOBILE.MIN_HEIGHT} !important;
    border: 1px solid ${e.COLORS.BORDER} !important;
    border-radius: 0 0 4px 4px !important;
    background-color: white !important;
  }

  .mobile-quill .ql-editor {
    width: 100% !important;
    max-width: 100% !important;
    height: auto !important;
    min-height: ${e.MOBILE.MIN_HEIGHT} !important;
    padding: ${e.SPACING.EDITOR_PADDING} !important;
    font-family: ${e.MOBILE.FONT_FAMILY} !important;
    font-size: ${e.MOBILE.FONT_SIZE} !important;
    font-weight: ${e.MOBILE.FONT_WEIGHT} !important;
    line-height: ${e.MOBILE.LINE_HEIGHT} !important;
    letter-spacing: ${e.MOBILE.LETTER_SPACING} !important;
    color: ${e.COLORS.TEXT} !important;
    word-wrap: break-word !important;
    word-break: break-word !important;
    overflow-wrap: break-word !important;
    white-space: pre-wrap !important;
  }

  .mobile-quill .ql-editor.ql-blank {
    min-height: ${e.MOBILE.MIN_HEIGHT} !important;
  }

  .mobile-quill .ql-editor.ql-blank::before {
    color: ${e.COLORS.PLACEHOLDER} !important;
    font-style: normal !important;
    left: ${e.SPACING.EDITOR_PADDING} !important;
    font-family: ${e.MOBILE.FONT_FAMILY} !important;
    font-size: ${e.MOBILE.FONT_SIZE} !important;
    font-weight: ${e.MOBILE.FONT_WEIGHT} !important;
  }

  /* 데스크톱 (768px 이상) */
  @media (min-width: 769px) {
    .w-md-editor-toolbar,
    .ql-toolbar {
      min-width: ${e.EDITOR.MIN_WIDTH} !important;
    }

    .w-md-container,
    .ql-container {
      min-width: ${e.EDITOR.MIN_WIDTH} !important;
    }
  }
`,tt=({mode:o,markdownContent:i,setMarkdownContent:d,quillRef:m})=>{const{uploadImage:n}=G(),a=r.useCallback(c=>{var h;const s=(h=m==null?void 0:m.current)==null?void 0:h.getEditor();if(s){const l=s.getSelection(!0);if(l)s.insertEmbed(l.index,"image",c),s.setSelection(l.index+1,0);else{const g=s.getLength();s.insertEmbed(g-1,"image",c)}}},[m]),p=r.useCallback((c,s)=>{const h=`
![${s}](${c})
`;d(i+h)},[i,d]),I=r.useCallback(async c=>{const s=await n(c);if(s)return o==="basic"?a(s):o==="markdown"&&p(s,c.name),s},[o,n,a,p]),T=r.useCallback(async c=>{c.preventDefault();const h=Array.from(c.dataTransfer.files).filter(l=>l.type.startsWith("image/"));for(const l of h)await I(l)},[I]),b=r.useCallback(async c=>{const h=Array.from(c.clipboardData.items).filter(l=>l.type.startsWith("image/"));if(h.length>0){c.preventDefault();for(const l of h){const g=l.getAsFile();g&&await I(g)}}},[I]);return{handleImageUpload:I,handleImageDrop:T,handleImagePaste:b}},et=o=>{if(!o||o.length===0)return{content:"",editorMode:"basic"};const i=o.filter(n=>n.contentType==="TEXT").sort((n,a)=>n.contentOrder-a.contentOrder).map(n=>n.content).join(`
`);if(W(i)){let n="";return o.sort((a,p)=>a.contentOrder-p.contentOrder).forEach(a=>{a.contentType==="TEXT"?n+=a.content+`
`:a.contentType==="IMAGE"&&(n+=`![](${a.content})
`)}),{content:n.trim(),editorMode:"markdown"}}const m=[];return o.sort((n,a)=>n.contentOrder-a.contentOrder).forEach((n,a)=>{if(n.contentType==="TEXT"){m.push(n.content);const p=o[a+1];p&&p.contentType==="TEXT"&&m.push("<p><br></p>")}else n.contentType==="IMAGE"&&m.push(`<p><img src="${n.content}" /></p>`)}),{content:m.join(""),editorMode:"basic"}},nt=()=>{const[o]=$(),i=o.get("edit"),{isLoggedIn:d}=q(),{title:m,setTitle:n,mode:a,setMode:p,basicContent:I,setBasicContent:T,markdownContent:b,setMarkdownContent:c,setEditPostId:s,reset:h}=F(),{data:l}=U(i||void 0,d,!!i),g=r.useRef(null);r.useEffect(()=>{if(i&&(l!=null&&l.data)){const{title:u,contents:D}=l.data,{content:w,editorMode:A}=et(D);s(i),n(u),p(A),A==="basic"?T(w):c(w)}else i||s(null)},[i,l,s,n,p,T,c]),r.useEffect(()=>{const u=()=>{window.innerWidth<768&&a==="markdown"&&p("basic")};return u(),window.addEventListener("resize",u),()=>window.removeEventListener("resize",u)},[a,p]),r.useEffect(()=>()=>{h()},[h]);const{handleImageUpload:x,handleImageDrop:O,handleImagePaste:f}=tt({mode:a,markdownContent:b,setMarkdownContent:c,quillRef:g}),S=r.useRef(x);r.useEffect(()=>{S.current=x},[x]);const R=r.useCallback(()=>{const u=document.createElement("input");u.setAttribute("type","file"),u.setAttribute("accept","image/*"),u.click(),u.onchange=async()=>{var w;const D=(w=u.files)==null?void 0:w[0];D&&await S.current(D)}},[]),j=r.useMemo(()=>({toolbar:{container:[E.WRITE.TOOLBAR.HEADERS,E.WRITE.TOOLBAR.TEXT_STYLES,E.WRITE.TOOLBAR.LISTS,E.WRITE.TOOLBAR.LINKS_IMAGES,E.WRITE.TOOLBAR.CLEAN],handlers:{image:R}}}),[R]),y=r.useMemo(()=>({toolbar:{container:[["image"]],handlers:{image:R}}}),[R]),v=J(),k=r.useCallback(u=>({intent:a===u?"primary":"secondary",variant:a===u?"solid":"outline",size:"sm"}),[a]);return{title:m,setTitle:n,mode:a,setMode:p,basicContent:I,setBasicContent:T,markdownContent:b,setMarkdownContent:c,quillRef:g,modules:j,mobileModules:y,editorStyles:v,getButtonProps:k,handleImageUpload:x,handleImageDrop:O,handleImagePaste:f}},ot=({className:o=""})=>{const d=_().pathname==="/blog/write";return t.jsx("div",{className:z("page-header-legacy-container",o),children:!d&&t.jsxs(t.Fragment,{children:[t.jsxs("div",{className:"flex items-center justify-center gap-1 rounded-[2px] px-2 pb-1 pt-0.5",children:[t.jsx(N,{size:"sm",className:"text-gray",children:t.jsx(V,{})}),t.jsx("span",{className:"text-xs font-normal leading-[160%] text-gray",children:"사진 추가하기"})]}),t.jsxs("div",{className:"flex items-center justify-center gap-1 rounded-[2px] px-2 pb-1 pt-0.5",children:[t.jsx(N,{size:"sm",className:"text-gray",children:t.jsx(Y,{})}),t.jsx("span",{className:"text-xs font-normal leading-[160%] text-gray",children:"파일 추가하기"})]})]})})};var at=P();const B=H(at),rt=C({base:["w-full bg-transparent outline-none self-stretch","text-2xl font-medium leading-[160%] tracking-[-0.08px]","text-black placeholder:text-gray-56","overflow-hidden text-ellipsis whitespace-nowrap"]}),it=C({slots:{container:"flex gap-2 mb-4",markdownButton:"hidden md:inline-flex"}}),st=({title:o,setTitle:i})=>t.jsx("input",{type:"text",placeholder:E.WRITE.PLACEHOLDERS.TITLE,value:o,onChange:d=>i(d.target.value),className:rt()}),lt=({setMode:o,getButtonProps:i})=>{const d=it();return t.jsxs("div",{className:d.container(),children:[t.jsx(M,{onClick:()=>o("basic"),...i("basic"),children:E.WRITE.MODES.BASIC}),t.jsx(M,{onClick:()=>o("markdown"),...i("markdown"),className:d.markdownButton(),children:E.WRITE.MODES.MARKDOWN})]})},ct=C({slots:{container:"flex flex-col items-center self-stretch",headerContainer:"flex flex-col items-center self-stretch border-b border-gray-96 bg-white",editorContainer:"flex w-full max-w-content p-3 px-4 justify-start items-center gap-2 self-stretch",editorWrapper:"flex w-full"}}),gt=()=>{const{title:o,setTitle:i,mode:d,setMode:m,basicContent:n,setBasicContent:a,markdownContent:p,setMarkdownContent:I,modules:T,mobileModules:b,editorStyles:c,getButtonProps:s,quillRef:h,handleImageDrop:l,handleImagePaste:g}=nt(),x=K(),O=ct();return t.jsxs("div",{children:[t.jsx("style",{children:c}),t.jsx(ot,{}),t.jsxs("div",{className:O.headerContainer(),children:[t.jsx(L,{height:"md"}),t.jsx(Q,{className:"w-full",title:"",renderTitle:t.jsx(st,{title:o,setTitle:i})}),t.jsx(L,{height:"md"})]}),t.jsxs("div",{className:O.container(),children:[t.jsx(L,{height:"md"}),!x&&t.jsx(lt,{mode:d,setMode:m,getButtonProps:s}),t.jsx("div",{className:O.editorContainer(),children:x?t.jsx("div",{className:O.editorWrapper(),onDrop:l,onDragOver:f=>f.preventDefault(),onPaste:g,children:t.jsx("div",{className:"m-mobile-quill w-full max-w-content",children:t.jsx(B,{ref:h,value:n,onChange:a,modules:b,placeholder:E.WRITE.PLACEHOLDERS.CONTENT,className:"mobile-quill w-full",theme:"snow"})})}):t.jsx(t.Fragment,{children:d==="basic"?t.jsx("div",{className:"desktop-quill w-full",onDrop:l,onDragOver:f=>f.preventDefault(),onPaste:g,children:t.jsx(B,{ref:h,value:n,onChange:a,modules:T,placeholder:E.WRITE.PLACEHOLDERS.CONTENT,theme:"snow"})}):t.jsx("div",{className:O.editorWrapper(),onDrop:l,onDragOver:f=>f.preventDefault(),onPaste:g,children:t.jsx(X,{value:p,onChange:f=>I(f||""),height:parseInt(e.EDITOR.HEIGHT)})})})})]}),t.jsx(L,{height:"lg"})]})};export{gt as default};
